"""
Simple wrapper class for Thorlabs PM100D using native TLPM DLL.
"""

import ctypes
from ctypes import c_uint32, c_double, c_bool, c_int16, byref, create_string_buffer
import math
import time

DLL_PATH = r"C:\Program Files\IVI Foundation\VISA\Win64\Bin\TLPM_64.dll"
SETTLE_TIME = 1


class PM100D:
    def __init__(self):
        self.tlpm = ctypes.CDLL(DLL_PATH)
        self.handle = None
        self.resource = None

    def find_device(self):
        """Find first available PM100D and return resource string."""
        count = c_uint32()
        self.tlpm.TLPM_findRsrc(0, byref(count))
        
        if count.value == 0:
            return None
        
        resource = create_string_buffer(256)
        self.tlpm.TLPM_getRsrcName(0, 0, resource)
        return resource.value.decode()

    def connect(self, resource=None):
        """Connect to PM100D."""
        if resource is None:
            resource = self.find_device()
            if resource is None:
                raise Exception("No PM100D found")
        
        self.resource = resource
        resource_buf = create_string_buffer(resource.encode())
        self.handle = c_uint32()
        
        result = self.tlpm.TLPM_init(resource_buf, c_bool(True), c_bool(True), byref(self.handle))
        if result != 0:
            raise Exception(f"Failed to connect. Error: {result}")
        
        # Discard first reading after connect (settling time)
        power = c_double()
        self.tlpm.TLPM_measPower(self.handle, byref(power))
        time.sleep(SETTLE_TIME)

    def close(self):
        """Disconnect from PM100D."""
        if self.handle:
            self.tlpm.TLPM_close(self.handle)
            self.handle = None

    def get_power(self):
        """Read power in Watts."""
        power = c_double()
        result = self.tlpm.TLPM_measPower(self.handle, byref(power))
        if result != 0:
            print(f"Warning: TLPM_measPower returned error code {result}")
        return power.value

    def get_power_dbm(self):
        """Read power in dBm."""
        power_w = self.get_power()
        if power_w > 0:
            return 10 * math.log10(power_w * 1000)
        return float('-inf')

    def set_wavelength(self, nm):
        """Set wavelength correction in nm."""
        self.tlpm.TLPM_setWavelength(self.handle, c_double(nm))
        # Discard first reading after wavelength change (settling time)
        power = c_double()
        self.tlpm.TLPM_measPower(self.handle, byref(power))
        time.sleep(SETTLE_TIME)

    def get_wavelength(self):
        """Get current wavelength setting in nm."""
        wavelength = c_double()
        self.tlpm.TLPM_getWavelength(self.handle, c_int16(0), byref(wavelength))
        return wavelength.value


if __name__ == "__main__":
    pm = PM100D()
    pm.connect()
    
    # Set wavelength to 1550 nm (includes settling time)
    pm.set_wavelength(1550)
    print(f"Wavelength: {pm.get_wavelength():.1f} nm")
    print(f"Power: {pm.get_power():.6e} W")
    print(f"Power: {pm.get_power_dbm():.2f} dBm")
    
    pm.close()
