"""
Wavelength sweep: scan laser across a range and record power at each point.
"""

from laser_TSL710 import TSL710
from PM100D import PM100D
import numpy as np
import matplotlib.pyplot as plt
import time
import os
from datetime import datetime

# Sweep parameters
START_NM = 1480
STOP_NM = 1600
STEP_NM = 3

# Data folder
DATA_FOLDER = "data"
os.makedirs(DATA_FOLDER, exist_ok=True)

# Generate timestamp for filenames
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# Connect to instruments
laser = TSL710()
pm = PM100D()
pm.connect()

# Generate wavelength array
wavelengths = np.arange(START_NM, STOP_NM + STEP_NM, STEP_NM)
powers_dbm = []

print(f"Sweeping from {START_NM} nm to {STOP_NM} nm (step: {STEP_NM} nm)")
print(f"Total points: {len(wavelengths)}")
print("-" * 40)

# Sweep loop
start_time = time.time()
for wl in wavelengths:
    # Set wavelength on laser and power meter
    laser.set_wavelength(wl)
    pm.set_wavelength(wl)
    
    # Small delay for laser to settle
    time.sleep(0.1)
    
    # Read power
    power_dbm = pm.get_power_dbm()
    powers_dbm.append(power_dbm)
    
    print(f"λ = {wl:.1f} nm  →  P = {power_dbm:.2f} dBm")

elapsed_time = time.time() - start_time
print("-" * 40)
print(f"Sweep complete! Duration: {elapsed_time:.1f} s")
laser.set_wavelength(1595)
pm.set_wavelength(1595)
# Cleanup
pm.close()
laser.close()

# Convert to numpy array
powers_dbm = np.array(powers_dbm)

# Save data to CSV with metadata header
csv_filename = os.path.join(DATA_FOLDER, f"sweep_{timestamp}.csv")
with open(csv_filename, 'w') as f:
    f.write(f"# Wavelength Sweep\n")
    f.write(f"# Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write(f"# Start: {START_NM} nm\n")
    f.write(f"# Stop: {STOP_NM} nm\n")
    f.write(f"# Step: {STEP_NM} nm\n")
    f.write(f"# Points: {len(wavelengths)}\n")
    f.write(f"# Duration: {elapsed_time:.1f} s\n")
    f.write(f"#\n")
    f.write("wavelength_nm,power_dBm\n")
    for wl, pwr in zip(wavelengths, powers_dbm):
        f.write(f"{wl:.2f},{pwr:.4f}\n")

print(f"Data saved to: {csv_filename}")



# Plot results
plt.figure(figsize=(10, 6))
plt.plot(wavelengths, powers_dbm, 'b.-', linewidth=1, markersize=4)
plt.xlabel('Wavelength (nm)')
plt.ylabel('Power (dBm)')
plt.title(f'Wavelength Sweep 16 parallel: {START_NM} - {STOP_NM} nm')
plt.grid(True, alpha=0.3)
plt.tight_layout()

# Save plot
plot_filename = os.path.join(DATA_FOLDER, f"sweep_16_p_{timestamp}.png")
plt.savefig(plot_filename, dpi=150)
print(f"Plot saved to: {plot_filename}")

plt.show()
   
