import pyvisa
import time


class TSL710:
    def __init__(self, address="GPIB1::29::INSTR", timeout=5000):
        rm = pyvisa.ResourceManager()
        self.laser = rm.open_resource(address)
        self.laser.timeout = timeout

    def close(self):
        self.laser.close()

    # Laser output on/off
    def output_on(self):
        self.laser.write(":POW:STAT 1")

    def output_off(self):
        self.laser.write(":POW:STAT 0")

    def get_output_state(self):
        return self.laser.query(":POW:STAT?").strip() == "1"

    # Shutter
    def shutter_open(self):
        self.laser.write(":POW:SHUT 0")

    def shutter_close(self):
        self.laser.write(":POW:SHUT 1")

    # Wavelength (nm)
    def set_wavelength(self, nm):
        self.laser.write(f":WAV {nm}")

    def get_wavelength(self):
        return float(self.laser.query(":WAV?").strip())

    # Power (dBm)
    def set_power(self, dbm):
        self.laser.write(f":POW {dbm}")

    def get_power(self):
        return float(self.laser.query(":POW?").strip())


if __name__ == "__main__":
    laser = TSL710()
    
    print("Turning laser ON...")
    laser.output_on()
    laser.set_power(0)
    time.sleep(0.5)
    
    print("Setting wavelength to 1550 nm...")
    laser.set_wavelength(1550)
    time.sleep(0.5)
    
    print(f"Wavelength: {laser.get_wavelength()} nm")
    print(f"Output: {'ON' if laser.get_output_state() else 'OFF'}")
    
    laser.close()
    print("Done")
